﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Raspberry.IO.GeneralPurpose")]
[assembly: AssemblyDescription("Raspberry Pi GPIO Mono Library")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d00cf11a-c5cf-4416-828e-afaa9b97e611")]
