﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Test.Gpio.MCP23017")]
[assembly: AssemblyDescription("Raspberry Pi MCP23017 Component Sample")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("7f472591-835d-460f-a318-ed6627b6bf97")]
