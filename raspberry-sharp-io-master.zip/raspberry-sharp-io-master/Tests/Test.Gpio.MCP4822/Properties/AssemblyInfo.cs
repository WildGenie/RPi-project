﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Test.Gpio.MCP4822")]
[assembly: AssemblyDescription("Raspberry Pi MCP4822 Component Sample")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("81a0aa1c-37b4-429d-9e95-d049372ef9df")]
