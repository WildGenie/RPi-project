﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Test.Gpio.MCP3008")]
[assembly: AssemblyDescription("Raspberry Pi MCP3008 Component Sample")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("72ce3a1e-982d-4a8f-bb3c-422d7c00b816")]
