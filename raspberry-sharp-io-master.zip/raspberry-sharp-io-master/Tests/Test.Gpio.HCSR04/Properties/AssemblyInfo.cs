﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Test.Gpio.HCSR04")]
[assembly: AssemblyDescription("Raspberry Pi HCSR04 Component Sample")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("9da308b4-e4c1-4179-bb66-6b5fae3439e0")]
