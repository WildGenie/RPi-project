using System;

namespace Raspberry.IO.Interop
{
    [Flags]
    public enum MemoryFlags
    {
        None = 0,
        Shared = 1
    }
}