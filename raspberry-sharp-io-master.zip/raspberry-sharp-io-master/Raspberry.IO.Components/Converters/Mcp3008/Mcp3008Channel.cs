namespace Raspberry.IO.Components.Converters.Mcp3008
{
    public enum Mcp3008Channel
    {
        Channel0 = 0,
        Channel1 = 1,
        Channel2 = 2,
        Channel3 = 3,
        Channel4 = 4,
        Channel5 = 5,
        Channel6 = 6,
        Channel7 = 7
    }
}