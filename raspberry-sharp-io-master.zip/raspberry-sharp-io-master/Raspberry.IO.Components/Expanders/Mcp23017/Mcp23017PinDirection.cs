namespace Raspberry.IO.Components.Expanders.Mcp23017
{
    public enum Mcp23017PinDirection
    {
        Input,
        Output
    }
}