namespace Raspberry.IO.Components.Expanders.Mcp23017
{
    public enum Mcp23017PinResistor
    {
        None,
        PullUp
    }
}