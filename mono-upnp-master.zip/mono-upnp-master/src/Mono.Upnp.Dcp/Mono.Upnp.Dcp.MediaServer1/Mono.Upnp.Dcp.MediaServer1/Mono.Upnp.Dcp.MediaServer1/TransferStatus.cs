// TransferStatus.cs auto-generated at 1/17/2009 8:08:36 PM by Sharpener

namespace Mono.Upnp.Dcp.MediaServer1
{
    public enum TransferStatus
    {
        COMPLETED,
        ERROR,
        IN_PROGRESS,
        STOPPED
    }
}