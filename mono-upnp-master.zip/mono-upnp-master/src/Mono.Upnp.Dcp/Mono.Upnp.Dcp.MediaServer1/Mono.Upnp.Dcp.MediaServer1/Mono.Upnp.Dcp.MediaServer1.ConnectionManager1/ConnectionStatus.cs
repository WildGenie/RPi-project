// ConnectionStatus.cs auto-generated at 1/17/2009 8:08:37 PM by Sharpener

namespace Mono.Upnp.Dcp.MediaServer1.ConnectionManager1
{
    public enum ConnectionStatus
    {
        OK,
        ContentFormatMismatch,
        InsufficientBandwidth,
        UnreliableChannel,
        Unknown
    }
}